import numpy as np
import cv2
import scipy.io as sio
from matplotlib import pyplot as plt
import skimage.feature
from numpy import linalg
from helper import *

def computeBriefFast(img, locs):

    patchWidth = 9
    nbits = 256
    compareX, compareY = makeTestPattern(patchWidth,nbits)
    m, n = img.shape

    halfWidth = patchWidth//2
    part1 = np.logical_and(halfWidth <= locs[:, 0], locs[:, 0] < m-halfWidth)
    part2 = np.logical_and(halfWidth <= locs[:, 1], locs[:, 1] < n-halfWidth)
    test_locs = locs[np.logical_and(part1, part2), :]

    zipped = np.column_stack((compareX, compareY))
    col1 = zipped[:, 0] % patchWidth - halfWidth
    row1 = zipped[:, 0] // patchWidth - halfWidth
    col2 = zipped[:, 1] % patchWidth - halfWidth
    row2 = zipped[:, 1] // patchWidth - halfWidth
    center0_row1 = np.add.outer(test_locs[:, 0], row1).astype(int)
    center1_col1 = np.add.outer(test_locs[:, 1], col1).astype(int)
    center0_row2 = np.add.outer(test_locs[:, 0], row2).astype(int)
    center1_col2 = np.add.outer(test_locs[:, 1], col2).astype(int)

    test_desc = np.zeros((test_locs.shape[0], zipped.shape[0]))
    test_desc[img[center0_row1, center1_col1] < img[center0_row2, center1_col2]] = 1

    return test_desc, test_locs