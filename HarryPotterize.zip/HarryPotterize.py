import numpy as np
import cv2
from skimage.feature import match
import skimage.io 
import skimage.color
from helper import *
from planarH import *
from matchPics import matchPics
from numpy.linalg import inv
from planarH import *
from ComputeBriefFast import *
#Import necessary functions




cv_cover = cv2.imread('../data/cv_cover.jpg')
cv_desk = cv2.imread('../data/cv_desk.png')
hp_cover = cv2.imread('../data/hp_cover.jpg')



matches, locs1, locs2 = matchPics(cv_cover, cv_desk)


locs1[:,[0, 1]] = locs1[:,[1, 0]]
locs2[:,[0, 1]] = locs2[:,[1, 0]]
x1 = locs1[matches[:,0]]

x2 = locs2[matches[:,1]]

H,inliers = computeH_ransac(x1,x2)
# H = inv(H)



resized_hp = cv2.resize(hp_cover,(cv_cover.shape[1],cv_cover.shape[0]))
mask = np.ones((cv_cover.shape[0],cv_cover.shape[1]),dtype="uint8")


template = [resized_hp,mask]

########################################################
# final = compositeHNew(H,templet,cv_desk)
# #img = cv_desk
# mask_warped = cv2.warpPerspective(mask,H,(cv_desk.shape[1],cv_desk.shape[0]))
# warped = cv2.warpPerspective(resized_hp,H,(cv_desk.shape[1],cv_desk.shape[0]))



# output = cv2.bitwise_and(cv_desk, cv_desk, mask=mask_warped)


# tempOut = np.where(mask_warped>0,0,1)
# tempOut = tempOut.astype('uint8')

# output = cv2.bitwise_and(cv_desk, cv_desk, mask=tempOut)

# final = output + warped

###########################3
final = compositeH(H,template,cv_desk)
# print(type(final))
# print(final.shape)
cv2.imshow('FINAL',final)

cv2.waitKey()
