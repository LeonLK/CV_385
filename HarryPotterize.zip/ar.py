import numpy as np
import cv2
from matchPics import *
from planarH import *
from helper import * 
from loadVid import loadVid
from ComputeBriefFast import *
#Import necessary functions

source_mov = '../data/ar_source.mov'
book_mov = '../data/book.mov'
cv_cover = cv2.imread('../data/cv_cover.jpg')

source = loadVid(source_mov)
book = loadVid(book_mov)

frame_height,frame_width = book[0].shape[0:2]

# Define the codec and create VideoWriter object.  The output is stored in 'outpy.avi' file.
out = cv2.VideoWriter('outpyNORM.avi',cv2.VideoWriter_fourcc('M','J','P','G'), 10, (frame_width,frame_height))

i = 0
numSample = min(source.shape[0],book.shape[0])
blackLinesSize = 44;
while (i < numSample):
    #do stuff
    sourceImg = source[i]
    sourceH,sourceW = sourceImg.shape[0:2]
    sourceImg = sourceImg[blackLinesSize:-blackLinesSize, :]
    bookImg = book[i]
    bookH,bookW = bookImg.shape[0:2]

    #Do the same as harrypotter
    matches, locs1, locs2 = matchPics(cv_cover, bookImg)
    locs1[:,[0, 1]] = locs1[:,[1, 0]]
    locs2[:,[0, 1]] = locs2[:,[1, 0]]
    x1 = locs1[matches[:,0]]
    x2 = locs2[matches[:,1]]
    H,inliers = computeH_ransac(x1,x2)
    H = inv(H)
    #replace hp_cover with sourceImg
    resized_hp = cv2.resize(sourceImg,(cv_cover.shape[1],cv_cover.shape[0]))
    mask = np.ones((cv_cover.shape[0],cv_cover.shape[1]),dtype="uint8")
    warped = cv2.warpPerspective(resized_hp,H,(bookImg.shape[1],bookImg.shape[0]))
    mask_warped = cv2.warpPerspective(mask,H,(bookImg.shape[1],bookImg.shape[0]))
    output = cv2.bitwise_and(bookImg, bookImg, mask=mask_warped)
    tempOut = np.where(mask_warped>0,0,1)
    tempOut = tempOut.astype('uint8')
    output = cv2.bitwise_and(bookImg, bookImg, mask=tempOut)
    final = output + warped
    out.write(final)
    i = i+1
# cv2.waitKey()
out.release()
# Default resolutions of the frame.
# frame_width = book[0]
# frame_height,frame_width = book[0].shape[0:2]

# # Define the codec and create VideoWriter object.  The output is stored in 'outpy.avi' file.
# out = cv2.VideoWriter('outpy.avi',cv2.VideoWriter_fourcc('M','J','P','G'), 10, (frame_width,frame_height))

# for itr in range(numSample):
    
#     # Generate random frame
#     frame = np.random.randn(frame_height,frame_width,3)*255
#     frame = np.uint8(frame)
#     # Write the frame into the file 'output.avi'
#     out.write(frame)

# # When everything done, release the video write object
# out.release()





