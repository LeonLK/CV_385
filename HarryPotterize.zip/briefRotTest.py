import numpy as np
import cv2
from numpy.lib.histograms import histogram
from matchPics import matchPics
from scipy import ndimage, misc
import matplotlib.pyplot as plt
from helper import briefMatch, plotMatches


#Q3.5
#Read the image and convert to grayscale, if necessary
I1 = cv2.imread('../data/cv_cover.jpg')
I1_rotate = I1.copy()

#Make histogram
hist = np.zeros(36)
bins = np.zeros(36)

if(len(I1.shape) != 2):
	I1_gray = cv2.cvtColor(I1, cv2.COLOR_BGR2GRAY)
	I1_rotate_gray = cv2.cvtColor(I1_rotate, cv2.COLOR_BGR2GRAY)
else:
	I1_gray = I1
	I1_rotate_gray = I1_rotate

for i in range(0,36):
	#Rotate Image
	rotatedI = ndimage.rotate(I1_rotate_gray, i*10, mode = 'constant')
	print(i*10)

	#Compute features, descriptors and Match features
	matches,locs1,locs2 = matchPics(I1_gray,rotatedI)

	#Update histogram
	hist[i] = matches.shape[0]
	bins[i] = i*10


print(hist)
# plt.bar(hist)
#Display histogram
plt.bar(bins,hist) # A bar chart
plt.xlabel('Degrees')
plt.ylabel('Num of Matches')
plt.show()


