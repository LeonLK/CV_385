import numpy as np
import cv2
import skimage.color
from helper import briefMatch
from helper import computeBrief
from helper import corner_detection
# from helper import computeBriefFast
from ComputeBriefFast import *

def matchPics(I1, I2):
	#I1, I2 : Images to match
	I1_copy = I1.copy()
	I2_copy = I2.copy()

	#Convert Images to GrayScale
	if(len(I1_copy.shape) != 2):	
		I1_gray = cv2.cvtColor(I1_copy, cv2.COLOR_BGR2GRAY)
	else:
		I1_gray = I1_copy
	if(len(I2_copy.shape) != 2):
		I2_gray = cv2.cvtColor(I2_copy, cv2.COLOR_BGR2GRAY)
	else:
		I2_gray = I2_copy
	
	#Detect Features in Both Images
	corner1 = corner_detection(I1_gray)
	corner2 = corner_detection(I2_gray)
	
	#Obtain descriptors for the computed feature locations
	# desc1,locs1 = computeBrief(I1_gray,corner1)
	# desc2, locs2 = computeBrief(I2_gray,corner2)
	desc1,locs1 = computeBriefFast(I1_gray,corner1)
	desc2, locs2 = computeBriefFast(I2_gray,corner2)

	#Match features using the descriptors
	matches = briefMatch(desc1,desc2)

	return matches, locs1, locs2
