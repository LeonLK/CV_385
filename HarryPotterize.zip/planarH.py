from matplotlib.pyplot import axis
import numpy as np
import cv2
import random
from numpy.linalg import inv
from numpy import linalg as LA, sqrt

# from planarH import *
def computeH(p1, p2):


    A = []
    for i in range(p1.shape[1]):
        A.append(np.array([p2[0, i], p2[1, i], 1, 0, 0, 0, -p1[0, i]*p2[0, i], -p1[0, i]*p2[1, i], -p1[0, i]]))
        A.append(np.array([0, 0, 0, -p2[0, i], -p2[1, i], -1, p1[1, i]*p2[0, i], p1[1, i]*p2[1, i], p1[1, i]]))

    A = np.array(A)
    u, s, v = np.linalg.svd(A)
    H2to1 = np.reshape(v[-1],(3,3))
    H2to1 = (1/H2to1.item(8)) * H2to1

    return H2to1



def computeH_norm(x1, x2):
    #Q3.7
    #Compute the centroid of the points
    x1 = np.transpose(x1)
    x2 = np.transpose(x2)
    N = x1.shape[0] # number of points
    pad = np.ones((N,1))
    #Find the centroid of x1
    m1 = np.mean(x1,0)
    x1_c,y1_c = m1

    #Find the centroid of x2
    m2 = np.mean(x2,0)           
    x2_c,y2_c = m2

    # s1 = np.sqrt(2)/((1/N)*np.sum((np.sqrt(abs(x1 - m1)**2))))
    # s2 = np.sqrt(2)/((1/N)*np.sum((np.sqrt(abs(x2 - m2)**2))))

    #Find the norm of each x,y pair.
    s1Norm = LA.norm(x1,axis=1)
    s2Norm = LA.norm(x2,axis=1)

    #find the norm of the biggest pair
    s1Max = max(s1Norm)
    s2Max = max(s2Norm)
    # divide everything by the largest norm and multiply by sqrt(2) to make sure max dist is sqrt(2)
    s1 = sqrt(2)/s1Max
    s2 = sqrt(2)/s2Max
    
    #Similarity transform 1
    #T =
    #[s 0 -s*x_c]
    #[0 s -s*y_c]
    #[0 0    1  ]
    t_x1 = -s1*x1_c #some trasnlation in x
    t_x2 = -s2*x2_c
    t_y1 = -s1*y1_c  #some translation in y
    t_y2 = -s2*y2_c

    T1 = np.array([[s1, 0, t_x1], [0, s1, t_y1], [0, 0, 1]]) 
    #Similarity transform 2
    T2 = np.array([[s2, 0, t_x2], [0, s2, t_y2], [0, 0, 1]])

    #Compute homography, first homogeonize the x,y coords
    x1 = np.append(x1,pad,axis = 1)
    x2 = np.append(x2,pad,axis = 1)
    #apply the transformation (Scale + translation at once)
    x1_p = np.matmul(T1,np.transpose(x1))
    x2_p = np.matmul(T2,np.transpose(x2))

    x1_p = x1_p[0:2,:]
    x2_p = x2_p[0:2,:]
    # print('XAFTERRRRR__\n',x1_p)
    # print(x2_p.shape)
    H_p = computeH(x1_p,x2_p)  ################!!!

    #Denormalization
    ##USE np.matmult or @
    # h1 = np.dot(H_p,T1)
    # h = np.dot(inv(T2),h1)
    # h1 = np.matmul(H_p,T2)
    # h = np.matmul(inv(T1),h1)
    # h = inv(T2) @ H_p @ T1
    h = inv(T1) @ H_p @ T2
    
    H2to1 = h
    # H2to1 = (1/H2to1.item(8)) * H2to1
    return H2to1

def computeH_ransac(locs1, locs2):

    p1 = locs1
    p2 = locs2
    numSample=2000
    tol=2
    max_count = 0
    bestH = np.zeros((3,3))
  
    arrayLen = len(locs1[:,0])
    inliers = np.zeros((arrayLen,1))
    i = 0
    while i < numSample:
        try:

            r1 = random.randint(0,arrayLen-1)
            r2 = random.randint(0,arrayLen-1)
            r3 = random.randint(0,arrayLen-1)
            r4 = random.randint(0,arrayLen-1)

            ind = np.array([r1,r2,r3,r4])
            ind = np.reshape(ind,(1,4))


            a1 = locs1[r1,:]
            a2 = locs1[r2,:]
            a3 = locs1[r3,:]
            a4 = locs1[r4,:]
            #get rand 4 points in locs2, with same index as locs1
            b1 = locs2[r1,:]
            b2 = locs2[r2,:]
            b3 = locs2[r3,:]
            b4 = locs2[r4,:]

            #reshape and stack the points
            r_p1 = np.concatenate((a1,a2,a3,a4),axis=0)
            r_p2 = np.concatenate((b1,b2,b3,b4),axis=0)
            r_p1 = np.transpose(np.reshape(r_p1,(4,2)))
            r_p2 = np.transpose(np.reshape(r_p2,(4,2)))

            H2to1 = computeH(r_p1, r_p2)
            # H2to1 = computeH_norm(r_p1, r_p2)

            #homogeonize p1 and p2 to perform vectorized calc
            p1_h = np.transpose(np.hstack((p1, np.ones((p1.shape[0], 1)))))
            p2_h = np.transpose(np.hstack((p2, np.ones((p2.shape[0], 1)))))

            #estimated p1
            est_p1 = np.dot(H2to1, p2_h)
            est_p1 = est_p1 / est_p1[2, :]
            
            #Calc error
            error = LA.norm(p1_h-est_p1,axis = 0)
            # compare the count of inliers
            inlier_count = error[error <= tol].size
            temp_inliers = np.zeros((arrayLen,1))
            for k in range(0,arrayLen):
                if error[k] <= tol:
                    temp_inliers[k] = 1
            if inlier_count > max_count:
                inliers = temp_inliers
                max_count = inlier_count
                bestH = H2to1
            i += 1
        except:
            print('something went wrong in RANSAC!!!!!')

    # Final H computation with all inliers (REMOVE IF TOO SLOW IDK)
    inliers = inliers.astype('uint8')
    resultX1 = np.zeros((arrayLen,2))
    resultX2 = np.zeros((arrayLen,2))
    for i in range(0,arrayLen):
        if (inliers[i] == 1):
            resultX1[i] = p1[i]
            resultX2[i] = p2[i]
    resultX1 = np.transpose(resultX1)
    resultX2 = np.transpose(resultX2)

    bestH = computeH(resultX1, resultX2)
    # bestH = computeH_norm(resultX1, resultX2)

    return bestH,inliers



def compositeH(H2to1, template, img):
    
    H = inv(H2to1)
    warped = cv2.warpPerspective(template[0],H,(img.shape[1],img.shape[0]))

    mask_warped = cv2.warpPerspective(template[1],H,(img.shape[1],img.shape[0]))

    output = cv2.bitwise_and(img, img, mask=mask_warped)

    tempOut = np.where(mask_warped>0,0,1)
    tempOut = tempOut.astype('uint8')

    output = cv2.bitwise_and(img, img, mask=tempOut)

    composite_img = output + warped

    return composite_img