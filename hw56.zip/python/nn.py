import numpy as np
from numpy.core import numeric
from util import *
# do not include any more libraries here!
# do not put any code outside of functions!

# Q 3.1.2
# initialize b to 0 vector
# b should be a 1D array, not a 2D array with a singleton dimension
# we will do XW + b. 
# X be [Examples, Dimensions]
def initialize_weights(in_size,out_size,params,name=''):
    print('In size:',in_size)
    print('out size:', out_size)
    c_num = np.sqrt(6)
    c_denom = np.sqrt(in_size+out_size)
    c = c_num/c_denom
    W = np.random.uniform(-c,c,(in_size,out_size))
    print('W init = ',W.shape)
    b = np.zeros(out_size)
    params['W' + name] = W
    params['b' + name] = b

# Q 3.2.1
# x is a matrix
# a sigmoid activation function
def sigmoid(x):
    res = 1/(1+np.exp(-x))
    return res

# Q 3.2.1
def forward(X,params,name='',activation=sigmoid):
    """
    Do a forward pass

    Keyword arguments:
    X -- input vector [Examples x D]
    params -- a dictionary containing parameters
    name -- name of the layer
    activation -- the activation function (default is sigmoid)
    """
    pre_act, post_act = None, None
    # get the layer parameters
    W = params['W' + name]
    b = params['b' + name]
    # print('input X shape:',X.shape)
    # your code here
    pre_act = X @ W + b
    post_act = activation(pre_act)
    # print('post act shape:',post_act.shape)

    # store the pre-activation and post-activation values
    # these will be important in backprop
    params['cache_' + name] = (X, pre_act, post_act)

    return post_act

# Q 3.2.2
# x is [examples,classes]
# softmax should be done for each row
def softmax(x):
    c = -np.max(x,axis=1) #max per example
    c = np.reshape(c,(x.shape[0],1))
    s_num = np.exp(x+c)
    s_denom = np.sum(s_num,axis=1)
    res = s_num/s_denom[:,np.newaxis]
    # print('PLSPLS:',res.shape)
    return res

# Q 3.2.3
# compute total loss and accuracy
# y is size [examples,classes]
# probs is size [examples,classes]
def compute_loss_and_acc(y, probs):
    loss = -np.sum(y*np.log(probs))
    acc = 0
    numSample = y.shape[0]
    predict = np.argmax(probs,axis=1)
    for i in range(numSample):
        # predict = np.argmax(probs[i,:])
        # print(int(y[i,predict[i]]))
        if(int(y[i,predict[i]]) == 1):
            acc += 1
    acc = acc/numSample
    
    # probs 
    
    return loss, acc 

# we give this to you
# because you proved it
# it's a function of post_act
def sigmoid_deriv(post_act):
    res = post_act*(1.0-post_act)
    return res

# Q 3.3.1
def backwards(delta,params,name='',activation_deriv=sigmoid_deriv):
    """
    Do a backwards pass

    Keyword arguments:
    delta -- errors to backprop
    params -- a dictionary containing parameters
    name -- name of the layer
    activation_deriv -- the derivative of the activation_func
    """
    grad_X, grad_W, grad_b = None, None, None
    # everything you may need for this layer
    W = params['W' + name]
    b = params['b' + name]
    X, pre_act, post_act = params['cache_' + name]
    # your code here
    # do the derivative through activation first
    # then compute the derivative W,b, and X
    # numEx,numClass = pre_act.shape
    # print('numEx: %i, numClass: %i'%(numEx,numClass))
    # print('X shape:',X.shape)
    # print('W shape:',W.shape)
    # print('b shape:',b.shape)
    # print('pre_act shape:',pre_act.shape)
    # print('post_act shape:',post_act.shape)
    # print('delta shape:',delta.shape)
    act_d = activation_deriv(post_act)
    # print('act_d shape:',act_d.shape)
    # print('act_driv * delta:',(act_d*delta).shape)
    d = act_d*delta
    # d = act_d*delta
    grad_X = np.transpose(W @ np.transpose(d)) # [(2x25)@(25x40)].T = 40x2 = X.shape   [(i x o) @ (o x Ex)].T = Ex x i = X
    grad_W = np.transpose(X) @ d #(40x2).T @ (40x25) = 2x25 = W.shape
    grad_b = np.sum(d,axis=0) #Sum the bias for all exmaples of a neuron, total of o many 
    # print('grad_X',grad_X.shape)
    # print('grad_W',grad_W.shape)
    # print('grad_b',grad_b.shape)
    # print('d shape:',d.shape)
    # grad_X = W @ d
    

    # store the gradients
    params['grad_W' + name] = grad_W
    params['grad_b' + name] = grad_b
    return grad_X


# Q 3.4.1
# split x and y into random batches
# return a list of [(batch1_x,batch1_y)...]
def get_random_batches(x,y,batch_size):
    batches = []
    numSample,_ = x.shape
    randIdx = np.random.choice(numSample,(numSample//batch_size,batch_size))
    testSplit = np.split(randIdx,len(randIdx))
    print('y:',y.shape)
    print('x',x.shape)
    for i in testSplit:
        batch_x = x[i,:]
        # print('batch_x',batch_x[0].shape)
        batch_y = y[i,:]
        # print('batch_y',batch_y[0].shape)
        batches.append((batch_x[0],batch_y[0]))
    
    # for i in range(randIdx.shape[0]):
    #     idx = randIdx[i] 
    #     batch_x = x[idx,:]
    #     batch_y = y[idx,:]
    #     batches.append((batch_x,batch_y))

    return batches
