import numpy as np

import skimage
import skimage.measure
import skimage.color
from skimage.morphology.grey import opening
import skimage.restoration
import skimage.filters
import skimage.morphology
import skimage.segmentation
from skimage.color import rgb2gray
from skimage.filters import threshold_otsu
import matplotlib.pyplot as plt
from skimage.morphology import closing, square
from skimage.measure import label, regionprops
from skimage.color import label2rgb
import matplotlib.patches as mpatches
import skimage.io
from statistics import stdev
import statistics
from scipy.ndimage import gaussian_filter

# takes a color image
# returns a list of bounding boxes and black_and_white image
def findLetters(image):
    # print('A')
    im1 = rgb2gray(image)
    # print(im1.shape)
    # im1 = skimage.transform.resize(im1, (1920, 1080))
    im1 = gaussian_filter(im1, sigma=1)
    r,c = im1.shape[0:2]
    thresh = threshold_otsu(im1)
    bw = opening(im1 > thresh, square(2))
    label_image = label(bw,1,False,2)
    bboxes = np.zeros((label_image.max(),4))
    # print(label_image.max())
    # print(bboxes.shape)
    # image_label_overlay = label2rgb(label_image, image=image, bg_label=0)
    count = 0
    areaTotal = []
    for region in regionprops(label_image):
        count += 1
        # print('area:',region.area)
        areaTotal.append(region.area)
    # print('check')
    avgArea = statistics.mean(areaTotal)
    # print('check2')
    stdArea = stdev(areaTotal)

    const = 1.8
    if (im1.shape == (3024, 4032)):
        const = 2.5

    i = 0
    for region in regionprops(label_image):
        # take regions with large enough areas
        # print(i)
        if region.area >= avgArea-const*stdArea:
            minr, minc, maxr, maxc = region.bbox
            minr -= 10
            minc -= 10
            maxr += 10
            maxc += 10
            if(minr < 0):
                minr = 0
            elif(minc < 0):
                minc = 0
            elif(maxr >= r):
                maxr = r-1
            elif(maxc >= c):
                maxc = c-1
            # print(type(minr))
            # print(region.bbox)
            # if(minr == None)
            # print('____')
            # if (int(minr) == 0 and int(minc) == 0 and int(maxr) == 0 and int(maxc) == 0):
            bboxes[i,:] = [minr,minc,maxr,maxc]
            i += 1
    # print('AHHHH')
    # print(bboxes[i:,:])
    bboxes = bboxes[0:i,:]    
    plt.show()
    # insert processing in here
    # one idea estimate noise -> denoise -> greyscale -> threshold -> morphology -> label -> skip small boxes 
    # this can be 10 to 15 lines of code using skimage functions

    
    return bboxes, bw

# import cv2

if __name__ == "__main__":
    image = skimage.io.imread('../images/02_letters.jpg')
    bboxes,bw = findLetters(image)
    # print(bw.min()
    # im)
    # print(bw.shape)
    # bw=np.uint8(bw)
    # print(bw)

    
    fig,ax = plt.subplots(figsize=(10, 6))
    # ax.imshow(bw)
    # cv2.imshow('graycsale image',bw)
    # cv2.waitKey(0)


    ax.imshow(bw)
    for i in range(bboxes.shape[0]):
        minr = bboxes[i,0]
        minc = bboxes[i,1]
        maxr = bboxes[i,2]
        maxc = bboxes[i,3]
        rect = mpatches.Rectangle((minc, minr), maxc - minc, maxr - minr,fill=False, edgecolor='red', linewidth=2)
        ax.add_patch(rect)
    ax.set_axis_off()
    plt.tight_layout()
    plt.show()
    # print(bboxes)
