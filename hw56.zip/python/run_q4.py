import numpy as np
import scipy.io
from nn import *
import pickle
import matplotlib.pyplot as plt 

train_data = scipy.io.loadmat('../data/nist36_train.mat')
valid_data = scipy.io.loadmat('../data/nist36_valid.mat')

train_x, train_y = train_data['train_data'], train_data['train_labels']
valid_x, valid_y = valid_data['valid_data'], valid_data['valid_labels']

max_iters = 66
# pick a batch size, learning rate
batch_size = 8
learning_rate = 2.2e-3
print('lr:',learning_rate)
hidden_size = 64

batches = get_random_batches(train_x,train_y,batch_size)
batch_num = len(batches)
print('batch_num = ',batch_num)

params = {}

# initialize layers here
examples, dimension = train_x.shape
examples, classes = train_y.shape
v_examples = valid_x.shape[0]
print('examples = ',examples)
print('v_examples = ',v_examples)

initialize_weights(dimension, hidden_size, params, 'layer1')
# initial_W = params['Wlayer1']
initialize_weights(hidden_size, classes, params, 'output')
import copy
param2 = copy.deepcopy(params)

train_loss = []
valid_loss = []
train_acc = []
valid_acc = []

if True:
    # with default settings, you should get loss < 150 and accuracy > 80%
    for itr in range(max_iters):
        total_loss = 0
        total_acc = 0
        for xb,yb in batches:
            h1 = forward(xb, params, 'layer1')
            probs = forward(h1, params, 'output', softmax)
            loss, acc = compute_loss_and_acc(yb, probs)
            total_loss += loss
            total_acc += acc
            delta = probs - yb
            grad = backwards(delta, params, 'output', linear_deriv)
            backwards(grad, params, 'layer1', sigmoid_deriv)
            # apply gradient
            params['Wlayer1'] -= learning_rate * params['grad_Wlayer1']
            params['blayer1'] -= learning_rate * params['grad_blayer1']
            params['Woutput'] -= learning_rate * params['grad_Woutput']
            params['boutput'] -= learning_rate * params['grad_boutput']
        total_acc = total_acc / batch_num
            
        if itr % 2 == 0:
            print("itr: {:02d} \t loss: {:.2f} \t acc : {:.2f}".format(itr,total_loss,total_acc))
    # run on validation set and report accuracy! should be above 75%
        v_h1 = forward(valid_x, params, 'layer1')
        v_probs = forward(v_h1, params, 'output', softmax)
        v_loss, v_acc = compute_loss_and_acc(valid_y, v_probs)
        # print('v_acc:',v_acc)
        train_acc.append(total_acc)
        valid_acc.append(v_acc)
        train_loss.append(total_loss / examples)
        valid_loss.append(v_loss / v_examples)
    valid_acc_print = valid_acc[-1]

    # Plot loss and acc
    # import matplotlib.pyplot as plt 
    # plt.figure()
    # plt.plot(np.arange(max_iters),train_loss)
    # plt.plot(np.arange(max_iters),valid_loss)
    # plt.legend(['Training','Validation'])
    # plt.title('Avg Loss, Learn Rate = 0.0022')
    # plt.show()

    # plt.figure()
    # plt.plot(np.arange(max_iters),train_acc)
    # plt.plot(np.arange(max_iters),valid_acc)
    # plt.legend(['Training','Validation'])
    # plt.title('Accuracy, Learn Rate = 0.0022')
    # plt.show()


    #End Plot
    print('________________________________________________________')
    print('Validation accuracy: ',valid_acc_print)
    if True: # view the data
        for crop in xb:
            import matplotlib.pyplot as plt
            plt.imshow(crop.reshape(32,32).T)
            plt.show()
    import pickle
    saved_params = {k:v for k,v in params.items() if '_' not in k}
    with open('q3_weights.pickle', 'wb') as handle:
        pickle.dump(saved_params, handle, protocol=pickle.HIGHEST_PROTOCOL)

    # Q4.3
    import matplotlib
    import tkinter
    matplotlib.use('agg')
    import matplotlib.pyplot as plt
    from mpl_toolkits.axes_grid1 import ImageGrid
    W1 = params['Wlayer1']
    # rows, cols = W_first.shape
    fig1 = plt.figure()
    grid = ImageGrid(fig1, 111, nrows_ncols=(8, 8), axes_pad=0.0)
    for i in range(hidden_size):
        grid[i].imshow(W1[:, i].reshape((32, 32)))
    plt.savefig("mygraph.png")
    W2 = param2['Wlayer1']
    fig2 = plt.figure()
    grid = ImageGrid(fig2, 111, nrows_ncols=(8, 8), axes_pad=0.0)
    for i in range(hidden_size):
        grid[i].imshow(W2[:, i].reshape((32, 32)))
    plt.savefig("mygraphInit.png")


# Q4.4
confusion_matrix = np.zeros((train_y.shape[1],train_y.shape[1]))

#Get test 
q3_params= pickle.load(open('q3_weights.pickle', 'rb'))
test_data = scipy.io.loadmat('../data/nist36_test.mat')
test_x, test_y = test_data['test_data'], test_data['test_labels']

test_h = forward(test_x,q3_params,'layer1')
test_probs = forward(test_h,q3_params,'output',softmax)
test_loss, test_acc = compute_loss_and_acc(test_y, test_probs)

for y,p in zip(test_y,test_probs):
    # print('p:',p.shape)
    # print(p)
    # print('y:',y.shape)
    # print(y)
    # break
    predicted = np.argmax(p)
    gt = np.argmax(y)
    confusion_matrix[predicted][gt] += 1



import string
plt.imshow(confusion_matrix,interpolation='nearest')
plt.grid(True)
plt.xticks(np.arange(36),string.ascii_uppercase[:26] + ''.join([str(_) for _ in range(10)]))
plt.yticks(np.arange(36),string.ascii_uppercase[:26] + ''.join([str(_) for _ in range(10)]))
# plt.show()
plt.savefig("confusedBox.png")
