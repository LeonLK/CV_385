import os
from urllib.parse import _NetlocResultMixinBase
import numpy as np
import matplotlib
matplotlib.use('agg') 
import matplotlib.pyplot as plt
import matplotlib.patches

import skimage
import skimage.measure
import skimage.color
import skimage.restoration
import skimage.io
import skimage.filters
import skimage.morphology
import skimage.segmentation

from nn import *
from q5 import *
# do not include any more libraries here!
# no opencv, no sklearn, etc!
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)

i = 1
for img in os.listdir('../images'):
    # i+=1
    # if (i!=2): continue
    print(img)
    im1 = skimage.img_as_float(skimage.io.imread(os.path.join('../images',img)))
    # print(im1.shape)

    bboxes, bw = findLetters(im1)
    # print('bboxes shape:',bboxes.shape)
    # print(bw)

    # THIS DOESN'T WOORRRK
    # plt.imshow(bw)
    # # plt.imshow(bw, cmap='gray')
    # for bbox in bboxes:
    #     minr, minc, maxr, maxc = bbox
    #     rect = matplotlib.patches.Rectangle((minc, minr), maxc - minc, maxr - minr,
    #                             fill=False, edgecolor='red', linewidth=2)
    #     plt.gca().add_patch(rect)
    # plt.show()


    # find the rows using..RANSAC, counting, clustering, etc.

    # print(b == box_all)
    # print('box_all',len(box_all))
    # print(box_all)
    # print('bbox',type(bboxes[29][0]))
    # bboxes.sort(key=lambda x: x[2])
    bboxesSorted = sorted(bboxes,key=lambda var: var[0])
    bboxesSorted = np.array(bboxesSorted)
    # print('SORTED SHAPE:',bboxesSorted.shape)

    allRows = []
    currRow = []
    currLine = 0
    # print(bboxes)
    currRow.append(bboxesSorted[0])
    for i in range(1,len(bboxesSorted)):
        curr = bboxesSorted[i]
        prev = bboxesSorted[i-1]
        if (curr[0] - prev[0] < 50):
            currRow.append(curr)
        else:
            currLine += 1
            allRows.append(currRow)
            currRow = []
            currRow.append(curr)
        if i == len(bboxesSorted)-1:
            allRows.append(currRow)
    # print('lines :',currLine+1)
    allRows = np.array(allRows)
    # allRows[:] = np.array(allRows[:])
    # print(type(allRows[0]))
    # print('ALLROWS SHAPE: ',allRows.shape)
    for i in range(allRows.shape[0]):
        allRows[i] = np.array(allRows[i])
    # print('Check Type New:',type(allRows[0]))

    
            

    
    # crop the bounding boxes
    # note.. before you flatten, transpose the image (that's how the dataset is!)
    # consider doing a square crop, and even using np.pad() to get your images looking more like the dataset
    
    # load the weights
    # run the crops through your neural network and print them out
    # print('crop')
    import pickle
    import string
    letters = np.array([_ for _ in string.ascii_uppercase[:26]] + [str(_) for _ in range(10)])
    params = pickle.load(open('q3_weights.pickle','rb'))
    n = 0
    for row in allRows:
        output = ""
        # print('type:',type(row))
        row = sorted(row,key=lambda x: x[1])
        for minr, minc, maxr, maxc in row:
            letter = bw[int(minr):int(maxr), int(minc):int(maxc)]
            # letter = skimage.transform.resize(letter, (32, 32))

            letter = skimage.transform.resize(letter, (28, 28))
            letter = np.pad(letter, (2, 2), 'constant',constant_values=(1, 1))
            # letter = skimage.transform.resize(letter, (26, 26))
            # letter = np.pad(letter, (3, 3), 'constant',constant_values=(1, 1))
            # print(letter.shape)
            # letterPrint = np.copy(letter)
            # plt.imshow(letter)
            # plt.savefig('cropped%i'%(n),cmap='Greys_r')
            # letter = letter.T
            letter = np.transpose(letter)

            # if (img == '01_list.jpg'):
            #     letter = np.pad(letter, ((20, 20), (20, 20)), 'constant', constant_values=1.0)
            #     letter = skimage.transform.resize(letter, (32, 32))
            #     letter = skimage.morphology.dilation(letter, skimage.morphology.square(1))
            # else:
            #     letter = np.pad(letter,((50,50),(50,50)),'constant',constant_values=1.0)
            #     letter = skimage.transform.resize(letter,(32,32))
            #     letter = skimage.morphology.dilation(letter,skimage.morphology.square(2))
            # # letter = 1.0-letter
            # plt.imshow(letter)
            # plt.savefig('cropped%i'%(n),cmap='Greys_r')
            # letter = letter.T

            x = letter.reshape(1, 32*32)
            h = forward(x, params, 'layer1')
            probs = forward(h, params, 'output', softmax)
            idx = np.argmax(probs[0, :])
            output += letters[idx]
            


            # plt.imshow(letterPrint)
            # plt.savefig('cropped%i'%(n),cmap='Greys_r')
            n +=1
            # print(letter)
            
            
        
            # letter = np.pad(letter, (2, 2), 'constant',
            #                 constant_values=(1, 1))
        print(output)
        # break
    # print(output)
    # break
    print('__________________________')
