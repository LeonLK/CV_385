import numpy as np
from scipy.interpolate import RectBivariateSpline
import copy

def LucasKanade(It, It1, rect):
    # Input: 
    #   It: template image
    #   It1: Current image
    #   rect: Current position of the object
    #   (top left, bot right coordinates: x1, y1, x2, y2)
    # Output:
    #   p: movement vector dx, dy
    
    # set up the threshold
    threshold = 0.01875
    maxIters = 100
    p = np.zeros(2)          
    x1,y1,x2,y2 = rect

    # put your implementation here

    #Get size of It,It1,rect
    h,w = It.shape[0:2]
    h1,w1 = It1.shape[0:2]
    rectW = x2-x1 #Add 1?
    rectH = y2-y1 #Add 1?
    
    #Find gradient of the current Image
    Iy, Ix = np.gradient(It1)
    #Interpolate It and It1
    template_spline = RectBivariateSpline(np.arange(h),np.arange(w),It)
    Ix_spline = RectBivariateSpline(np.arange(h),np.arange(w),Ix)
    Iy_spline = RectBivariateSpline(np.arange(h),np.arange(w),Iy)
    It1_spline = RectBivariateSpline(np.arange(h1),np.arange(w1),It1)

    #Make grid with the init rect
    yGrid,xGrid = np.meshgrid(np.arange(y1,y1+rectH+1), np.arange(x1,x1+rectW+1))
    # y = np.reshape(yGrid,(1,yGrid.shape[0]*yGrid.shape[1]))
    # x = np.reshape(xGrid,(1,xGrid.shape[0]*xGrid.shape[1]))
    y = np.reshape(yGrid,(-1,1))
    x = np.reshape(xGrid,(-1,1))
    x = x.astype(np.float64)
    y = y.astype(np.float64)
    template = template_spline.ev(y, x)
    # print(type(temp_ev))
    # template = np.array(temp_ev)
    dp = np.ones(2) * threshold
    i = 0
    while(i < maxIters and np.linalg.norm(dp) >= threshold):
        xi = np.copy(x)
        yi = np.copy(y)
        # print('x1 type:',type(xi))
        # print('p[0] type:',type(p[0]))
        xi += p[0] #patch x?
        yi += p[1] #patch y?
        Ax = Ix_spline.ev(yi,xi)
        Ay = Iy_spline.ev(yi,xi)
        A = np.hstack((Ax,Ay))

        img = It1_spline.ev(yi,xi)
        # image = np.array(It1_spline.ev(yi.flatten(), xi.flatten()).tolist())
        b = template - img
        dp,_,_,_ = np.linalg.lstsq(A,b)
        # print(dp)
        # print(p)
        dp = np.reshape(dp,(2,))
        p += dp
        i += 1
        
        # i += 1
    
    
     





    return p

