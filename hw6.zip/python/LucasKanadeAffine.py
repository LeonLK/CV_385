import numpy as np
from scipy.interpolate import RectBivariateSpline
import matplotlib.pyplot as plt

def LucasKanadeAffine(It, It1, rect):
    # Input: 
    #   It: template image
    #   It1: Current image
    #   rect: Current position of the object
    #   (top left, bot right coordinates: x1, y1, x2, y2)
    # Output:
    #   M: the Affine warp matrix [2x3 numpy array]

    # set up the threshold
    threshold = 0.01875
    maxIters = 100
    p = np.zeros((6,1))
    x1,y1,x2,y2 = rect

    # put your implementation here

    #Reshape M
    M = np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]])
    p = np.reshape(M,(-1,1))
    #Get size of It,It1,rect
    h,w = It.shape[0:2]
    # print('h : %i, w : %i ' % (h,w))
    h1,w1 = It1.shape[0:2]
    rectW = x2-x1 #Add 1?
    rectH = y2-y1 #Add 1?
    
    #Find gradient of the current Image
    Iy, Ix = np.gradient(It1)
    #Interpolate It and It1
    template_spline = RectBivariateSpline(np.arange(h),np.arange(w),It)
    Ix_spline = RectBivariateSpline(np.arange(h),np.arange(w),Ix)
    Iy_spline = RectBivariateSpline(np.arange(h),np.arange(w),Iy)
    It1_spline = RectBivariateSpline(np.arange(h1),np.arange(w1),It1)

    #Make grid with the init rect
    yGrid,xGrid = np.meshgrid(np.arange(y1,y1+rectH+1), np.arange(x1,x1+rectW+1))
    y = np.reshape(yGrid,(-1,1))
    x = np.reshape(xGrid,(-1,1))
    x = x.astype(np.float64)
    y = y.astype(np.float64)
    
    #Get template
    template = template_spline.ev(y, x)
    dp = np.ones((6,1)) * threshold
    i = 0
    while(i < maxIters and np.linalg.norm(dp) >= threshold):
        # print(i)
        xi = np.copy(x)
        yi = np.copy(y)
        #Mod (Commented)
        # X = np.hstack((yi,xi,np.ones((x.shape[0],1)))) #Homogeniuzed coord
        X = np.hstack((xi,yi,np.ones((x.shape[0],1)))) #Homogeniuzed coord test
        IM = M @ np.transpose(X) #Size 2x3 @ 3 x N = 2 x N
    
        xi_IM = IM[0,:]
        yi_IM = IM[1,:]

        #end MOD
       

        Ax = np.reshape(Ix_spline.ev(yi_IM,xi_IM),(-1,1))
        Ay = np.reshape(Iy_spline.ev(yi_IM,xi_IM),(-1,1))
        # A = np.hstack((y*Ay, x*Ay,Ay,y*Ax,x*Ax,Ax)) #N x 6
        # A = np.hstack((x*Ay, y*Ay,Ay,x*Ax,y*Ax,Ax)) #N x 6
        A = np.hstack((np.multiply(x,Ax), np.multiply(y,Ax),Ax,np.multiply(x,Ay),np.multiply(y,Ay),Ay)) #Lag?
        # A = np.hstack((y*Ax, x*Ax,Ax,y*Ay,x*Ay,Ay)) #noppe

        img = It1_spline.ev(yi_IM,xi_IM)
        img = np.reshape(img,(-1,1)) #Same as template (checked)
        b = template - img
        dp,_,_,_ = np.linalg.lstsq(A,b,rcond=None) # shape (6,1)
        p += dp
        # dp = np.reshape(dp,(2,3))
        # M = M + dp
        
        i += 1
    M = np.reshape(p,(2,3))
    # reshape the output affine matrix
    # M = np.array([[1.0+p[0], p[1],    p[2]],
    #              [p[3],     1.0+p[4], p[5]]]).reshape(2, 3)
    print('exit i : %i'%(i))
    return M
